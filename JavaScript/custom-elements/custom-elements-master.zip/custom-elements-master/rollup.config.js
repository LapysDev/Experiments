export default {
  input: 'src/custom-elements.js',
  output: { file: 'custom-elements.min.js', format: 'iife', sourcemap: true }
};
